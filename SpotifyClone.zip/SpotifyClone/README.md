# Music Streaming App

A Spotify-inspired music streaming web application built with Flask, featuring user authentication, playlist management, and YouTube music downloading capabilities.

## Features

- **User Authentication**: Secure registration and login system
- **Music Library**: Upload audio files from your computer
- **YouTube Integration**: Download and convert YouTube videos to MP3
- **Playlist Management**: Create and manage custom playlists
- **Audio Player**: HTML5-based audio player with controls
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Dark Theme**: Spotify-inspired dark interface

## Technologies Used

### Backend
- **Flask**: Web framework
- **SQLite**: Database for user data and music metadata
- **Flask-Login**: User session management
- **yt_dlp**: YouTube video downloading
- **ffmpeg**: Audio processing and conversion
- **werkzeug**: Security utilities

### Frontend
- **HTML5**: Semantic markup
- **Bootstrap 5**: Responsive CSS framework
- **Custom CSS**: Spotify-inspired dark theme
- **Vanilla JavaScript**: Audio player and interactivity
- **Font Awesome**: Icons

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd music-streaming-app
   ```

2. **Install Python dependencies**
   ```bash
   pip install flask flask-login werkzeug yt_dlp ffmpeg-python sqlalchemy flask-sqlalchemy
   