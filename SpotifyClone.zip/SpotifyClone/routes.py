import os
import logging
import subprocess
from flask import render_template, request, redirect, url_for, flash, jsonify, send_file, abort
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import yt_dlp
import requests
from urllib.parse import urlparse
from app import app, db
from models import User, Song, Playlist, playlist_songs

ALLOWED_EXTENSIONS = {'mp3', 'wav', 'ogg', 'm4a'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    if current_user.is_authenticated:
        # Get recent songs and user's playlists
        recent_songs = Song.query.filter_by(user_id=current_user.id).order_by(Song.uploaded_at.desc()).limit(8).all()
        most_played_songs = Song.query.filter_by(user_id=current_user.id).filter(Song.play_count > 0).order_by(Song.play_count.desc()).limit(8).all()
        
        # Get liked songs
        from sqlalchemy import text
        liked_songs_result = db.session.execute(text('''
            SELECT s.* FROM song s 
            JOIN user_likes ul ON s.id = ul.song_id 
            WHERE ul.user_id = :user_id 
            ORDER BY ul.liked_at DESC 
            LIMIT 8
        '''), {"user_id": current_user.id}).fetchall()
        
        # Convert to Song objects
        liked_songs = []
        for row in liked_songs_result:
            song = Song.query.get(row[0])  # row[0] is the song id
            if song:
                liked_songs.append(song)
        
        user_playlists = Playlist.query.filter_by(user_id=current_user.id).order_by(Playlist.created_at.desc()).limit(6).all()
        return render_template('index.html', recent_songs=recent_songs, most_played_songs=most_played_songs, liked_songs=liked_songs, user_playlists=user_playlists)
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = request.form.get('remember', False)
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user, remember=remember)
            flash('Welcome back!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Invalid email or password.', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already taken.', 'error')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password)
        )
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('Registration failed. Please try again.', 'error')
            logging.error(f"Registration error: {e}")
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/library')
@login_required
def library():
    page = request.args.get('page', 1, type=int)
    songs = Song.query.filter_by(user_id=current_user.id).order_by(Song.uploaded_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    playlists = Playlist.query.filter_by(user_id=current_user.id).all()
    return render_template('library.html', songs=songs, playlists=playlists)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        # Handle file upload
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Add user ID to filename to avoid conflicts
                filename = f"{current_user.id}_{filename}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                try:
                    file.save(filepath)
                    
                    # Get file info
                    file_size = os.path.getsize(filepath)
                    title = request.form.get('title') or os.path.splitext(file.filename)[0]
                    artist = request.form.get('artist') or 'Unknown Artist'
                    
                    # Create song record
                    song = Song(
                        title=title,
                        artist=artist,
                        filename=filename,
                        file_size=file_size,
                        user_id=current_user.id,
                        source='upload'
                    )
                    
                    db.session.add(song)
                    db.session.commit()
                    flash('File uploaded successfully!', 'success')
                    return redirect(url_for('library'))
                    
                except Exception as e:
                    if os.path.exists(filepath):
                        os.remove(filepath)
                    flash('Upload failed. Please try again.', 'error')
                    logging.error(f"Upload error: {e}")
            else:
                flash('Invalid file type. Please upload MP3, WAV, OGG, or M4A files.', 'error')
        
        # Handle YouTube download
        elif 'youtube_url' in request.form:
            youtube_url = request.form.get('youtube_url')
            if youtube_url:
                try:
                    # Configure yt-dlp options
                    ydl_opts = {
                        'format': 'bestaudio/best',
                        'outtmpl': os.path.join(app.config['UPLOAD_FOLDER'], f'{current_user.id}_%(title)s.%(ext)s'),
                        'postprocessors': [{
                            'key': 'FFmpegExtractAudio',
                            'preferredcodec': 'mp3',
                            'preferredquality': '192',
                        }],
                    }
                    
                    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                        # Get video info first
                        info = ydl.extract_info(youtube_url, download=False)
                        title = info.get('title', 'Unknown Title')
                        artist = info.get('uploader', 'Unknown Artist')
                        
                        # Download thumbnail
                        thumbnail_filename = None
                        thumbnail_url = info.get('thumbnail')
                        if thumbnail_url:
                            try:
                                # Create thumbnails directory if it doesn't exist
                                thumb_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'thumbnails')
                                os.makedirs(thumb_dir, exist_ok=True)
                                
                                # Download thumbnail
                                response = requests.get(thumbnail_url)
                                if response.status_code == 200:
                                    # Generate unique filename for thumbnail
                                    safe_title = secure_filename(title)
                                    thumbnail_filename = f"{current_user.id}_{safe_title}.jpg"
                                    thumbnail_path = os.path.join(thumb_dir, thumbnail_filename)
                                    
                                    with open(thumbnail_path, 'wb') as f:
                                        f.write(response.content)
                            except Exception as e:
                                logging.error(f"Failed to download thumbnail: {e}")
                        
                        # Download the audio
                        ydl.download([youtube_url])
                        
                        # Find the downloaded file
                        expected_filename = f"{current_user.id}_{title}.mp3"
                        expected_filename = secure_filename(expected_filename)
                        filepath = os.path.join(app.config['UPLOAD_FOLDER'], expected_filename)
                        
                        # Sometimes yt-dlp creates files with slightly different names
                        # Find the most recently created file for this user
                        import glob
                        pattern = os.path.join(app.config['UPLOAD_FOLDER'], f"{current_user.id}_*.mp3")
                        files = glob.glob(pattern)
                        if files:
                            filepath = max(files, key=os.path.getctime)
                            filename = os.path.basename(filepath)
                            file_size = os.path.getsize(filepath)
                            
                            # Create song record
                            song = Song(
                                title=title,
                                artist=artist,
                                filename=filename,
                                file_size=file_size,
                                user_id=current_user.id,
                                source='youtube',
                                thumbnail=thumbnail_filename
                            )
                            
                            db.session.add(song)
                            db.session.commit()
                            flash('YouTube audio downloaded successfully!', 'success')
                            return redirect(url_for('library'))
                
                except Exception as e:
                    flash('Failed to download from YouTube. Please check the URL and try again.', 'error')
                    logging.error(f"YouTube download error: {e}")
    
    return render_template('upload.html')

@app.route('/playlist/<int:playlist_id>')
@login_required
def playlist(playlist_id):
    playlist = Playlist.query.filter_by(id=playlist_id, user_id=current_user.id).first_or_404()
    songs = playlist.songs
    all_user_songs = Song.query.filter_by(user_id=current_user.id).all()
    return render_template('playlist.html', playlist=playlist, songs=songs, all_user_songs=all_user_songs)

@app.route('/create_playlist', methods=['POST'])
@login_required
def create_playlist():
    name = request.form.get('name')
    description = request.form.get('description', '')
    
    if name:
        playlist = Playlist(
            name=name,
            description=description,
            user_id=current_user.id
        )
        
        try:
            db.session.add(playlist)
            db.session.commit()
            flash('Playlist created successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Failed to create playlist.', 'error')
            logging.error(f"Playlist creation error: {e}")
    
    return redirect(url_for('library'))

@app.route('/add_to_playlist', methods=['POST'])
@login_required
def add_to_playlist():
    song_id = request.form.get('song_id', type=int)
    playlist_id = request.form.get('playlist_id', type=int)
    
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first()
    playlist = Playlist.query.filter_by(id=playlist_id, user_id=current_user.id).first()
    
    if song and playlist:
        if song not in playlist.songs:
            playlist.songs.append(song)
            try:
                db.session.commit()
                flash(f'Added "{song.title}" to "{playlist.name}"!', 'success')
            except Exception as e:
                db.session.rollback()
                flash('Failed to add song to playlist.', 'error')
                logging.error(f"Add to playlist error: {e}")
        else:
            flash('Song is already in this playlist.', 'info')
    
    return redirect(request.referrer or url_for('library'))

@app.route('/remove_from_playlist', methods=['POST'])
@login_required
def remove_from_playlist():
    song_id = request.form.get('song_id', type=int)
    playlist_id = request.form.get('playlist_id', type=int)
    
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first()
    playlist = Playlist.query.filter_by(id=playlist_id, user_id=current_user.id).first()
    
    if song and playlist and song in playlist.songs:
        playlist.songs.remove(song)
        try:
            db.session.commit()
            flash(f'Removed "{song.title}" from "{playlist.name}".', 'success')
        except Exception as e:
            db.session.rollback()
            flash('Failed to remove song from playlist.', 'error')
            logging.error(f"Remove from playlist error: {e}")
    
    return redirect(request.referrer or url_for('library'))

@app.route('/delete_song/<int:song_id>', methods=['POST'])
@login_required
def delete_song(song_id):
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first_or_404()
    
    try:
        # Remove file from filesystem
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], song.filename)
        if os.path.exists(filepath):
            os.remove(filepath)
        
        # Remove from database
        db.session.delete(song)
        db.session.commit()
        flash('Song deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Failed to delete song.', 'error')
        logging.error(f"Delete song error: {e}")
    
    return redirect(request.referrer or url_for('library'))

@app.route('/delete_playlist/<int:playlist_id>', methods=['POST'])
@login_required
def delete_playlist(playlist_id):
    playlist = Playlist.query.filter_by(id=playlist_id, user_id=current_user.id).first_or_404()
    
    try:
        db.session.delete(playlist)
        db.session.commit()
        flash('Playlist deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Failed to delete playlist.', 'error')
        logging.error(f"Delete playlist error: {e}")
    
    return redirect(url_for('library'))

@app.route('/stream/<int:song_id>')
@login_required
def stream_song(song_id):
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first_or_404()
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], song.filename)
    
    if os.path.exists(filepath):
        # Increment play count
        song.play_count += 1
        try:
            db.session.commit()
        except Exception as e:
            logging.error(f"Failed to update play count: {e}")
            db.session.rollback()
        
        return send_file(filepath)
    else:
        abort(404)

@app.route('/thumbnail/<int:song_id>')
@login_required
def get_thumbnail(song_id):
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first()
    if not song or not song.thumbnail:
        abort(404)
    
    thumb_path = os.path.join(app.config['UPLOAD_FOLDER'], 'thumbnails', song.thumbnail)
    if not os.path.exists(thumb_path):
        abort(404)
    
    return send_file(thumb_path)

@app.route('/search')
@login_required
def search():
    query = request.args.get('q', '').strip()
    
    if query:
        # Search songs
        songs = Song.query.filter(
            Song.user_id == current_user.id,
            (Song.title.ilike(f'%{query}%') | Song.artist.ilike(f'%{query}%'))
        ).all()
        
        # Search playlists
        playlists = Playlist.query.filter(
            Playlist.user_id == current_user.id,
            Playlist.name.ilike(f'%{query}%')
        ).all()
        
        return render_template('library.html', songs=songs, playlists=playlists, search_query=query)
    
    return redirect(url_for('library'))

@app.route('/like_song', methods=['POST'])
@login_required
def like_song():
    song_id = request.form.get('song_id', type=int)
    song = Song.query.filter_by(id=song_id, user_id=current_user.id).first()
    
    if song:
        from sqlalchemy import text
        try:
            # Check if already liked
            existing = db.session.execute(text("SELECT 1 FROM user_likes WHERE user_id = :user_id AND song_id = :song_id"), 
                                        {"user_id": current_user.id, "song_id": song_id}).first()
            
            if existing:
                # Unlike
                db.session.execute(text("DELETE FROM user_likes WHERE user_id = :user_id AND song_id = :song_id"), 
                                 {"user_id": current_user.id, "song_id": song_id})
                flash('Removed from liked songs.', 'info')
            else:
                # Like
                db.session.execute(text("INSERT INTO user_likes (user_id, song_id) VALUES (:user_id, :song_id)"), 
                                 {"user_id": current_user.id, "song_id": song_id})
                flash('Added to liked songs!', 'success')
            
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            flash('Failed to update liked status.', 'error')
            logging.error(f"Like song error: {e}")
    
    return redirect(request.referrer or url_for('library'))
