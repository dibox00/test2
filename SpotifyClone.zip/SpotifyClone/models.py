from app import db
from flask_login import UserMixin
from datetime import datetime

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    songs = db.relationship('Song', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    playlists = db.relationship('Playlist', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def is_song_liked(self, song_id):
        from sqlalchemy import text
        result = db.session.execute(text("SELECT 1 FROM user_likes WHERE user_id = :user_id AND song_id = :song_id"), 
                                  {"user_id": self.id, "song_id": song_id}).first()
        return result is not None
    
    def __repr__(self):
        return f'<User {self.username}>'

class Song(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    artist = db.Column(db.String(200), default='Unknown Artist')
    filename = db.Column(db.String(255), nullable=False)
    duration = db.Column(db.Integer, default=0)  # Duration in seconds
    file_size = db.Column(db.Integer, default=0)  # File size in bytes
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    source = db.Column(db.String(50), default='upload')  # 'upload' or 'youtube'
    play_count = db.Column(db.Integer, default=0)  # Track how many times played
    thumbnail = db.Column(db.String(500))  # Store thumbnail filename or URL
    
    def __repr__(self):
        return f'<Song {self.title} by {self.artist}>'

class Playlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Many-to-many relationship with songs
    songs = db.relationship('Song', secondary='playlist_songs', backref='playlists')
    
    def __repr__(self):
        return f'<Playlist {self.name}>'

# Association table for many-to-many relationship between playlists and songs
playlist_songs = db.Table('playlist_songs',
    db.Column('playlist_id', db.Integer, db.ForeignKey('playlist.id'), primary_key=True),
    db.Column('song_id', db.Integer, db.ForeignKey('song.id'), primary_key=True),
    db.Column('added_at', db.DateTime, default=datetime.utcnow)
)

# Association table for user liked songs
user_likes = db.Table('user_likes',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('song_id', db.Integer, db.ForeignKey('song.id'), primary_key=True),
    db.Column('liked_at', db.DateTime, default=datetime.utcnow)
)
