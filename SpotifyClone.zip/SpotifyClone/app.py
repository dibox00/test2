import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///music_app.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# File upload configuration
app.config['UPLOAD_FOLDER'] = 'static/music'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Create upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

with app.app_context():
    # Import models and routes
    import models
    import routes
    
    # Add hasattr to Jinja2 globals
    app.jinja_env.globals['hasattr'] = hasattr
    
    # Create all database tables
    db.create_all()
    
    # Add play_count column if it doesn't exist
    try:
        from sqlalchemy import text
        db.session.execute(text('ALTER TABLE song ADD COLUMN play_count INTEGER DEFAULT 0'))
        db.session.commit()
    except Exception:
        # Column already exists or other error
        db.session.rollback()
    
    # Create user_likes table if it doesn't exist
    try:
        db.session.execute(text('''
            CREATE TABLE IF NOT EXISTS user_likes (
                user_id INTEGER NOT NULL,
                song_id INTEGER NOT NULL,
                liked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, song_id),
                FOREIGN KEY (user_id) REFERENCES user(id),
                FOREIGN KEY (song_id) REFERENCES song(id)
            )
        '''))
        db.session.commit()
    except Exception:
        db.session.rollback()
