// Music Player JavaScript

class MusicPlayer {
    constructor() {
        this.audio = document.getElementById('audioPlayer');
        this.playerContainer = document.getElementById('playerContainer');
        this.playPauseBtn = document.getElementById('playPauseBtn');
        this.prevBtn = document.getElementById('prevBtn');
        this.nextBtn = document.getElementById('nextBtn');
        this.shuffleBtn = document.getElementById('shuffleBtn');
        this.repeatBtn = document.getElementById('repeatBtn');
        this.progressContainer = document.getElementById('progressContainer');
        this.progressFill = document.getElementById('progressFill');
        this.volumeBar = document.getElementById('volumeBar');
        this.currentTimeSpan = document.getElementById('currentTime');
        this.totalTimeSpan = document.getElementById('totalTime');
        this.playerTitle = document.getElementById('playerTitle');
        this.playerArtist = document.getElementById('playerArtist');
        
        this.currentSongIndex = 0;
        this.playlist = [];
        this.originalPlaylist = [];
        this.isPlaying = false;
        this.isLoading = false;
        this.isShuffled = false;
        this.repeatMode = 'off'; // 'off', 'all', 'one'
        
        this.initializeEventListeners();
        this.initializePlayButtons();
        this.loadVolume();
    }
    
    initializeEventListeners() {
        // Play/Pause button
        this.playPauseBtn.addEventListener('click', () => {
            this.togglePlayPause();
        });
        
        // Previous/Next buttons
        this.prevBtn.addEventListener('click', () => {
            this.playPrevious();
        });
        
        this.nextBtn.addEventListener('click', () => {
            this.playNext();
        });
        
        // Shuffle button
        if (this.shuffleBtn) {
            this.shuffleBtn.addEventListener('click', () => {
                this.toggleShuffle();
            });
        }
        
        // Repeat button
        if (this.repeatBtn) {
            this.repeatBtn.addEventListener('click', () => {
                this.toggleRepeat();
            });
        }
        
        // Progress container
        if (this.progressContainer) {
            this.progressContainer.addEventListener('click', (e) => {
                this.seekToPosition(e);
            });
        }
        
        // Volume bar
        this.volumeBar.addEventListener('input', () => {
            this.setVolume();
        });
        
        // Audio events
        this.audio.addEventListener('loadstart', () => {
            this.isLoading = true;
            this.updatePlayButton();
        });
        
        this.audio.addEventListener('canplay', () => {
            this.isLoading = false;
            this.updatePlayButton();
        });
        
        this.audio.addEventListener('timeupdate', () => {
            this.updateProgress();
        });
        
        this.audio.addEventListener('ended', () => {
            if (this.repeatMode === 'one') {
                this.audio.currentTime = 0;
                this.play();
            } else {
                this.playNext();
            }
        });
        
        this.audio.addEventListener('play', () => {
            this.isPlaying = true;
            this.updatePlayButton();
        });
        
        this.audio.addEventListener('pause', () => {
            this.isPlaying = false;
            this.updatePlayButton();
        });
        
        this.audio.addEventListener('loadedmetadata', () => {
            this.updateTotalTime();
        });
        
        this.audio.addEventListener('error', (e) => {
            console.error('Audio error:', e);
            this.showError('Failed to load audio file');
        });
    }
    
    initializePlayButtons() {
        // Add click handlers to all play buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.play-btn')) {
                e.preventDefault();
                const button = e.target.closest('.play-btn');
                const songId = button.dataset.songId;
                const title = button.dataset.title;
                const artist = button.dataset.artist;
                
                if (songId) {
                    this.loadSong(songId, title, artist);
                }
            }
        });
    }
    
    loadSong(songId, title, artist) {
        if (this.isLoading) return;
        
        const streamUrl = `/stream/${songId}`;
        
        // Update player info
        this.playerTitle.textContent = title;
        this.playerArtist.textContent = artist;
        
        // Load audio
        this.audio.src = streamUrl;
        this.audio.load();
        
        // Show player
        this.playerContainer.style.display = 'block';
        
        // Play when ready
        this.audio.addEventListener('canplay', () => {
            this.play();
        }, { once: true });
        
        // Update current song info
        this.currentSong = { id: songId, title, artist };
        
        // Build playlist from current page
        this.buildPlaylistFromPage();
    }
    
    buildPlaylistFromPage() {
        const playButtons = document.querySelectorAll('.play-btn');
        this.playlist = Array.from(playButtons).map(btn => ({
            id: btn.dataset.songId,
            title: btn.dataset.title,
            artist: btn.dataset.artist
        }));
        
        // Find current song index
        this.currentSongIndex = this.playlist.findIndex(song => 
            song.id === this.currentSong.id
        );
    }
    
    play() {
        if (this.audio.src && !this.isLoading) {
            // Ensure volume is set properly before playing
            const isMobile = window.innerWidth <= 768;
            if (isMobile) {
                this.audio.volume = 1.0;
            }
            
            const playPromise = this.audio.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.error('Play failed:', error);
                    // Try to reload and play again for mobile compatibility
                    this.audio.load();
                    setTimeout(() => {
                        this.audio.play().catch(e => {
                            console.error('Retry play failed:', e);
                            this.showError('Unable to play audio. Please tap the play button again.');
                        });
                    }, 100);
                });
            }
        }
    }
    
    pause() {
        this.audio.pause();
    }
    
    togglePlayPause() {
        if (this.isPlaying) {
            this.pause();
        } else {
            this.play();
        }
    }
    
    playPrevious() {
        if (this.playlist.length === 0) return;
        
        this.currentSongIndex = this.currentSongIndex > 0 
            ? this.currentSongIndex - 1 
            : this.playlist.length - 1;
        
        const song = this.playlist[this.currentSongIndex];
        this.loadSong(song.id, song.title, song.artist);
    }
    
    playNext() {
        if (this.playlist.length === 0) return;
        
        if (this.repeatMode === 'all' || this.currentSongIndex < this.playlist.length - 1) {
            this.currentSongIndex = (this.currentSongIndex + 1) % this.playlist.length;
            const song = this.playlist[this.currentSongIndex];
            this.loadSong(song.id, song.title, song.artist);
        } else if (this.repeatMode === 'off') {
            // Stop at the end of playlist
            this.pause();
        }
    }
    
    seekTo() {
        if (this.audio.duration) {
            const seekTime = (this.progressBar.value / 100) * this.audio.duration;
            this.audio.currentTime = seekTime;
        }
    }
    
    setVolume() {
        const volume = this.volumeBar.value / 100;
        this.audio.volume = volume;
        this.saveVolume(volume);
        
        // Update volume icon
        const volumeIcon = document.getElementById('volumeIcon');
        if (volumeIcon) {
            if (volume === 0) {
                volumeIcon.className = 'fas fa-volume-mute';
            } else if (volume < 0.5) {
                volumeIcon.className = 'fas fa-volume-down';
            } else {
                volumeIcon.className = 'fas fa-volume-up';
            }
        }
    }
    
    updateProgress() {
        if (this.audio.duration && this.progressFill) {
            const progress = (this.audio.currentTime / this.audio.duration) * 100;
            this.progressFill.style.width = progress + '%';
            this.updateCurrentTime();
        }
    }
    
    seekToPosition(e) {
        if (this.audio.duration) {
            const rect = this.progressContainer.getBoundingClientRect();
            const percentage = (e.clientX - rect.left) / rect.width;
            const seekTime = percentage * this.audio.duration;
            this.audio.currentTime = seekTime;
        }
    }
    
    toggleShuffle() {
        this.isShuffled = !this.isShuffled;
        
        if (this.isShuffled) {
            this.shuffleBtn.classList.add('text-success');
            this.shufflePlaylist();
        } else {
            this.shuffleBtn.classList.remove('text-success');
            this.playlist = [...this.originalPlaylist];
            this.currentSongIndex = this.playlist.findIndex(song => 
                song.id === this.currentSong.id
            );
        }
    }
    
    shufflePlaylist() {
        this.originalPlaylist = [...this.playlist];
        const currentSong = this.playlist[this.currentSongIndex];
        
        // Remove current song and shuffle the rest
        const otherSongs = this.playlist.filter((_, index) => index !== this.currentSongIndex);
        for (let i = otherSongs.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [otherSongs[i], otherSongs[j]] = [otherSongs[j], otherSongs[i]];
        }
        
        // Put current song first
        this.playlist = [currentSong, ...otherSongs];
        this.currentSongIndex = 0;
    }
    
    toggleRepeat() {
        if (this.repeatMode === 'off') {
            this.repeatMode = 'all';
            this.repeatBtn.classList.add('text-success');
            this.repeatBtn.querySelector('i').className = 'fas fa-redo';
        } else if (this.repeatMode === 'all') {
            this.repeatMode = 'one';
            this.repeatBtn.querySelector('i').className = 'fas fa-redo-alt';
        } else {
            this.repeatMode = 'off';
            this.repeatBtn.classList.remove('text-success');
            this.repeatBtn.querySelector('i').className = 'fas fa-redo';
        }
    }
    
    updateCurrentTime() {
        const current = this.formatTime(this.audio.currentTime);
        this.currentTimeSpan.textContent = current;
    }
    
    updateTotalTime() {
        const total = this.formatTime(this.audio.duration);
        this.totalTimeSpan.textContent = total;
    }
    
    updatePlayButton() {
        const icon = this.playPauseBtn.querySelector('i');
        
        if (this.isLoading) {
            icon.className = 'fas fa-spinner fa-spin';
        } else if (this.isPlaying) {
            icon.className = 'fas fa-pause';
        } else {
            icon.className = 'fas fa-play';
        }
    }
    
    formatTime(seconds) {
        if (isNaN(seconds)) return '0:00';
        
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    saveVolume(volume) {
        localStorage.setItem('musicPlayerVolume', volume);
    }
    
    loadVolume() {
        // Check if we're on mobile (volume control is hidden)
        const isMobile = window.innerWidth <= 768;
        
        if (isMobile) {
            // On mobile, always set volume to maximum
            this.audio.volume = 1.0;
            if (this.volumeBar) {
                this.volumeBar.value = 100;
            }
        } else {
            const savedVolume = localStorage.getItem('musicPlayerVolume');
            if (savedVolume !== null) {
                this.volumeBar.value = savedVolume * 100;
                this.audio.volume = savedVolume;
            } else {
                this.volumeBar.value = 50;
                this.audio.volume = 0.5;
            }
            this.setVolume();
        }
    }
    
    showError(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-danger border-0 position-fixed';
        toast.style.top = '20px';
        toast.style.right = '20px';
        toast.style.zIndex = '9999';
        toast.setAttribute('role', 'alert');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-exclamation-triangle me-2"></i>${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove element after it's hidden
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Only handle shortcuts if no input is focused
    if (document.activeElement.tagName === 'INPUT' || 
        document.activeElement.tagName === 'TEXTAREA') {
        return;
    }
    
    switch (e.code) {
        case 'Space':
            e.preventDefault();
            if (window.musicPlayer) {
                window.musicPlayer.togglePlayPause();
            }
            break;
        case 'ArrowLeft':
            e.preventDefault();
            if (window.musicPlayer) {
                window.musicPlayer.playPrevious();
            }
            break;
        case 'ArrowRight':
            e.preventDefault();
            if (window.musicPlayer) {
                window.musicPlayer.playNext();
            }
            break;
    }
});

// Initialize player when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.musicPlayer = new MusicPlayer();
});

// Media Session API for mobile notifications and controls
if ('mediaSession' in navigator) {
    const updateMediaSession = (title, artist) => {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: title,
            artist: artist,
            album: 'Music App',
            artwork: [
                { src: '/static/images/icon-96x96.png', sizes: '96x96', type: 'image/png' },
                { src: '/static/images/icon-128x128.png', sizes: '128x128', type: 'image/png' },
                { src: '/static/images/icon-192x192.png', sizes: '192x192', type: 'image/png' },
                { src: '/static/images/icon-256x256.png', sizes: '256x256', type: 'image/png' },
            ]
        });
    };
    
    // Set up media session action handlers
    navigator.mediaSession.setActionHandler('play', () => {
        if (window.musicPlayer) {
            window.musicPlayer.play();
        }
    });
    
    navigator.mediaSession.setActionHandler('pause', () => {
        if (window.musicPlayer) {
            window.musicPlayer.pause();
        }
    });
    
    navigator.mediaSession.setActionHandler('previoustrack', () => {
        if (window.musicPlayer) {
            window.musicPlayer.playPrevious();
        }
    });
    
    navigator.mediaSession.setActionHandler('nexttrack', () => {
        if (window.musicPlayer) {
            window.musicPlayer.playNext();
        }
    });
    
    // Update media session when song changes
    document.addEventListener('songChanged', (e) => {
        updateMediaSession(e.detail.title, e.detail.artist);
    });
}
